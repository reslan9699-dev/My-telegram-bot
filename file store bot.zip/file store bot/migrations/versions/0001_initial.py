"""Initial tables: posts, files, download_logs

Revision ID: 0001
Revises:
Create Date: 2026-08-04
"""

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = "0001"
down_revision: str | None = None
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    op.create_table(
        "posts",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("message_text", sa.Text(), nullable=True),
        sa.Column("photo_file_id", sa.String(length=512), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "files",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("post_id", sa.Integer(), nullable=False),
        sa.Column("telegram_file_id", sa.String(length=512), nullable=False),
        sa.Column("file_type", sa.String(length=32), nullable=False),
        sa.Column("original_filename", sa.String(length=512), nullable=True),
        sa.ForeignKeyConstraint(["post_id"], ["posts.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_files_post_id"), "files", ["post_id"], unique=False)

    op.create_table(
        "download_logs",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("post_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("downloaded_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["post_id"], ["posts.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_download_logs_post_id"), "download_logs", ["post_id"], unique=False)
    op.create_index(op.f("ix_download_logs_user_id"), "download_logs", ["user_id"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_download_logs_user_id"), table_name="download_logs")
    op.drop_index(op.f("ix_download_logs_post_id"), table_name="download_logs")
    op.drop_table("download_logs")

    op.drop_index(op.f("ix_files_post_id"), table_name="files")
    op.drop_table("files")

    op.drop_table("posts")
