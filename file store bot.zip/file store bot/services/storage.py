"""Persistence layer: temporary upload sessions and database operations.

Files are stored only as Telegram file_ids - never downloaded to disk.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.models import DownloadLog, File, Post
from utils import FilePayload

logger = logging.getLogger(__name__)


@dataclass
class UploadSession:
    """In-memory collection of files staged for a new post."""

    files: list[FilePayload] = field(default_factory=list)


class TemporaryUploadStorage:
    """Holds pending admin upload sessions between FSM steps."""

    def __init__(self) -> None:
        self._sessions: dict[int, UploadSession] = {}

    def get(self, admin_id: int) -> UploadSession:
        session = self._sessions.get(admin_id)
        if session is None:
            session = UploadSession()
            self._sessions[admin_id] = session
        return session

    def clear(self, admin_id: int) -> None:
        self._sessions.pop(admin_id, None)


class PostService:
    """All database operations around posts, files and downloads."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create_post(
        self,
        message_text: str | None,
        photo_file_id: str | None,
        files: list[FilePayload],
    ) -> Post:
        post = Post(message_text=message_text, photo_file_id=photo_file_id)
        self._session.add(post)
        await self._session.flush()

        for payload in files:
            self._session.add(
                File(
                    post_id=post.id,
                    telegram_file_id=payload.telegram_file_id,
                    file_type=payload.file_type,
                    original_filename=payload.original_filename,
                )
            )

        await self._session.commit()
        await self._session.refresh(post)
        logger.info("Post created: id=%d files=%d", post.id, len(files))
        return post

    async def get_post_with_files(self, post_id: int) -> Post | None:
        result = await self._session.execute(
            select(Post).options(selectinload(Post.files)).where(Post.id == post_id)
        )
        return result.scalar_one_or_none()

    async def record_download(self, post_id: int, user_id: int) -> None:
        self._session.add(DownloadLog(post_id=post_id, user_id=user_id))
        await self._session.commit()

    async def get_statistics(self) -> dict[str, int]:
        posts = await self._session.scalar(select(func.count(Post.id))) or 0
        files = await self._session.scalar(select(func.count(File.id))) or 0
        downloads = await self._session.scalar(select(func.count(DownloadLog.id))) or 0
        return {
            "posts": int(posts),
            "files": int(files),
            "downloads": int(downloads),
        }


temp_upload_storage = TemporaryUploadStorage()
