"""Publishes posts to the public channel with a Download button."""

from __future__ import annotations

import logging

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError

from config import settings
from keyboards.inline import download_keyboard
from utils import escape_html

logger = logging.getLogger(__name__)


class Publisher:
    """Sends a post (text and/or photo) to the channel with an inline Download button."""

    def __init__(self, bot: Bot) -> None:
        self._bot = bot
        self._bot_username: str | None = None

    async def _resolve_bot_username(self) -> str:
        """Fetch and cache the bot's public username (needed for the deep link)."""
        if self._bot_username is None:
            me = await self._bot.get_me()
            self._bot_username = me.username
        return self._bot_username

    async def publish(
        self,
        post_id: int,
        message_text: str | None,
        photo_file_id: str | None,
    ) -> bool:
        bot_username = await self._resolve_bot_username()
        markup = download_keyboard(bot_username, post_id)
        try:
            if photo_file_id:
                caption = escape_html(message_text) if message_text else None
                await self._bot.send_photo(
                    chat_id=settings.channel_id,
                    photo=photo_file_id,
                    caption=caption,
                    reply_markup=markup,
                )
            else:
                text = message_text or "Files available for download."
                await self._bot.send_message(
                    chat_id=settings.channel_id,
                    text=escape_html(text),
                    reply_markup=markup,
                )
        except TelegramForbiddenError:
            logger.error("Bot lacks permission to publish to channel %s", settings.channel_id)
            return False
        except TelegramBadRequest as exc:
            logger.error("Failed to publish to %s: %s", settings.channel_id, exc)
            return False
        except Exception:
            logger.exception("Unexpected error publishing to %s", settings.channel_id)
            return False

        logger.info("Post published: id=%d channel=%s", post_id, settings.channel_id)
        return True
