"""User handlers: private chat entry points and deep-link downloads."""

from __future__ import annotations

import logging

from aiogram import Router
from aiogram.filters import CommandObject, CommandStart
from aiogram.types import Message

from handlers.callbacks import deliver_download

logger = logging.getLogger(__name__)

user_router = Router(name="user")

_DOWNLOAD_PREFIX = "download_"


@user_router.message(CommandStart(deep_link=True))
async def user_start_deep_link(message: Message, command: CommandObject) -> None:
    payload = (command.args or "").strip()
    if payload.startswith(_DOWNLOAD_PREFIX):
        post_id = int(payload[len(_DOWNLOAD_PREFIX):])
        ok, text = await deliver_download(message.bot, message.from_user.id, post_id)
        await message.answer(text)
        return
    await message.answer(
        "This bot distributes protected files.\n"
        "Use the Download button on a post in the channel to receive the files."
    )


@user_router.message(CommandStart())
async def user_start(message: Message) -> None:
    await message.answer(
        "This bot distributes protected files.\n"
        "Use the Download button on a post in the channel to receive the files."
    )


@user_router.message()
async def user_fallback(message: Message) -> None:
    await message.answer(
        "Use the Download button on a post in the channel to receive the files."
    )
