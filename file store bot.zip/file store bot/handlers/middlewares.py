"""Middlewares: rate limiting for user actions."""

from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from config import settings


class RateLimitMiddleware(BaseMiddleware):
    """Sliding-window rate limiter keyed by Telegram user id."""

    def __init__(self, max_actions: int, window_seconds: int) -> None:
        self.max_actions = max_actions
        self.window_seconds = window_seconds
        self._events: dict[int, deque[float]] = defaultdict(deque)

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user_id = getattr(getattr(event, "from_user", None), "id", None)
        if user_id is None:
            return await handler(event, data)

        if not self._allow(user_id):
            if isinstance(event, CallbackQuery):
                await event.answer("Too many requests. Please wait a moment.", show_alert=True)
            elif isinstance(event, Message):
                await event.answer("Too many requests. Please wait a moment.")
            return None

        return await handler(event, data)

    def _allow(self, user_id: int) -> bool:
        now = time.monotonic()
        events = self._events[user_id]
        while events and now - events[0] > self.window_seconds:
            events.popleft()
        if len(events) >= self.max_actions:
            return False
        events.append(now)
        return True


def build_rate_limit_middleware() -> RateLimitMiddleware:
    """Instantiate the rate limiter from current settings."""
    return RateLimitMiddleware(settings.rate_limit_max, settings.rate_limit_window)
