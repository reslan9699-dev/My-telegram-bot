"""Callback handlers: download requests and download delivery.

Downloads are delivered to the user's private chat so they work from any surface
(channel post, private chat or forwarded message).
"""

from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery

from config import settings
from database.database import SessionLocal
from services.storage import PostService
from utils import FilePayload, send_file_by_type

logger = logging.getLogger(__name__)

callbacks_router = Router(name="callbacks")

# Prevents concurrent duplicate downloads of the same post by the same user.
_download_locks: dict[tuple[int, int], asyncio.Lock] = {}

_progress_update_interval = settings.progress_update_interval


async def deliver_download(bot: Bot, user_id: int, post_id: int) -> tuple[bool, str]:
    """Fetch the post's files and send them to the user's private chat.

    Returns a (success, message) tuple that callers can turn into a reply.
    """
    key = (user_id, post_id)
    lock = _download_locks.setdefault(key, asyncio.Lock())
    if lock.locked():
        return False, "Download already in progress."

    async with lock:
        try:
            async with SessionLocal() as db:
                post = await PostService(db).get_post_with_files(post_id)
                if post is None:
                    return False, "Post not found."
                payloads = [
                    FilePayload(
                        telegram_file_id=f.telegram_file_id,
                        file_type=f.file_type,
                        original_filename=f.original_filename,
                    )
                    for f in post.files
                ]

            if not payloads:
                return False, "This post has no files."

            await send_files_with_progress(bot, user_id, payloads)

            async with SessionLocal() as db:
                await PostService(db).record_download(post_id, user_id)

            logger.info(
                "Download completed: user=%d post=%d files=%d", user_id, post_id, len(payloads)
            )
            return True, f"Files sent: {len(payloads)}"
        except TelegramBadRequest as exc:
            logger.warning(
                "Telegram error during download: user=%d post=%d error=%s", user_id, post_id, exc
            )
            return False, "Could not send the files. Try again later."
        except Exception:
            logger.exception("Unexpected download error: user=%d post=%d", user_id, post_id)
            return False, "Something went wrong. Try again later."
        finally:
            if not lock.locked():
                _download_locks.pop(key, None)


@callbacks_router.callback_query()
async def unknown_callback(callback: CallbackQuery) -> None:
    """Catch-all for stale/unknown callback data (e.g. old keyboards)."""
    await callback.answer("Unknown action.", show_alert=False)


async def send_files_with_progress(bot: Bot, chat_id: int, payloads: list[FilePayload]) -> None:
    """Send every file in order, showing a live progress message for large batches."""
    total = len(payloads)
    if total == 1:
        await send_file_by_type(bot, chat_id, payloads[0])
        return

    progress_msg = await bot.send_message(chat_id, f"Sending files... 0/{total} completed...")
    last_update = 0
    for index, payload in enumerate(payloads, start=1):
        await send_file_by_type(bot, chat_id, payload)
        if index - last_update >= _progress_update_interval or index == total:
            try:
                await progress_msg.edit_text(f"Sending files... {index}/{total} completed...")
            except TelegramBadRequest:
                pass
            last_update = index

    try:
        await progress_msg.delete()
    except TelegramBadRequest:
        pass
