"""Admin handlers: panel, upload flow, publishing and statistics."""

from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from config import settings
from database.database import SessionLocal
from keyboards.reply import admin_panel_keyboard
from services.publisher import Publisher
from services.storage import PostService, temp_upload_storage
from states import AdminUploadStates
from utils import get_file_payload

logger = logging.getLogger(__name__)

admin_router = Router(name="admin")

# Only the configured admin can ever reach these handlers.
admin_router.message.filter(F.from_user.id == settings.admin_id)


@admin_router.message(CommandStart())
async def admin_start(message: Message, state: FSMContext) -> None:
    await state.set_state(AdminUploadStates.Idle)
    await message.answer("Welcome to the admin panel.", reply_markup=admin_panel_keyboard())


@admin_router.message(F.text == "Upload New Post")
async def start_upload(message: Message, state: FSMContext) -> None:
    temp_upload_storage.clear(message.from_user.id)
    await state.set_state(AdminUploadStates.ReceivingFiles)
    await message.answer(
        "Upload flow started.\n\n"
        "Send all files. Supported: PDF, ZIP, RAR, MP4, MP3, photos, documents and any Telegram media.\n"
        "Current files: 0",
        reply_markup=admin_panel_keyboard(with_finish=True),
    )


@admin_router.message(AdminUploadStates.ReceivingFiles, F.text == "Finish Upload")
async def finish_upload(message: Message, state: FSMContext) -> None:
    session = temp_upload_storage.get(message.from_user.id)
    if not session.files:
        await message.answer(
            "No files received yet. Send at least one file or press Cancel Current Upload."
        )
        return
    await state.set_state(AdminUploadStates.WaitingPost)
    await message.answer(
        f"Now send the post.\n\nFiles staged: {len(session.files)}\n"
        "Accepted formats: text, or a photo with an optional caption.",
        reply_markup=admin_panel_keyboard(),
    )


@admin_router.message(F.text == "Cancel Current Upload")
async def cancel_upload(message: Message, state: FSMContext) -> None:
    current = await state.get_state()
    temp_upload_storage.clear(message.from_user.id)
    if current in {AdminUploadStates.ReceivingFiles.state, AdminUploadStates.WaitingPost.state}:
        await state.set_state(AdminUploadStates.Idle)
        await message.answer(
            "Upload cancelled. Temporary files cleared.", reply_markup=admin_panel_keyboard()
        )
    else:
        await message.answer("There is no upload in progress.")


@admin_router.message(F.text == "Statistics")
async def admin_statistics(message: Message) -> None:
    async with SessionLocal() as session:
        stats = await PostService(session).get_statistics()
    text = (
        "<b>Statistics</b>\n"
        f"Total posts: {stats['posts']}\n"
        f"Total files: {stats['files']}\n"
        f"Total downloads: {stats['downloads']}"
    )
    await message.answer(text)


@admin_router.message(AdminUploadStates.WaitingPost)
async def receive_post(message: Message, state: FSMContext) -> None:
    if message.text and not message.photo:
        text = message.text
        photo_file_id = None
    elif message.photo:
        photo_file_id = message.photo[-1].file_id
        text = message.caption or ""
    else:
        await message.answer("Accepted formats: text or a photo (with an optional caption).")
        return

    session = temp_upload_storage.get(message.from_user.id)
    await state.set_state(AdminUploadStates.Publishing)

    try:
        async with SessionLocal() as db:
            post = await PostService(db).create_post(text, photo_file_id, session.files)
    except Exception:
        logger.exception("Failed to store the post in the database")
        await state.set_state(AdminUploadStates.WaitingPost)
        await message.answer("Could not store the post. Please try again.")
        return

    ok = await Publisher(message.bot).publish(post.id, text, photo_file_id)

    temp_upload_storage.clear(message.from_user.id)
    await state.set_state(AdminUploadStates.Idle)

    if ok:
        await message.answer(
            f"Post published successfully.\nPost ID: {post.id}",
            reply_markup=admin_panel_keyboard(),
        )
    else:
        await message.answer(
            "The post was stored but publishing to the channel failed. "
            "Check that the bot is an admin of the channel.",
            reply_markup=admin_panel_keyboard(),
        )


@admin_router.message(AdminUploadStates.ReceivingFiles)
async def receive_file(message: Message) -> None:
    payload = get_file_payload(message)
    if payload is None:
        await message.answer("Send a file, or press Finish Upload.")
        return

    session = temp_upload_storage.get(message.from_user.id)
    session.files.append(payload)
    count = len(session.files)
    logger.info("Admin upload: added %s (total=%d)", payload.file_type, count)
    await message.answer(f"File added.\nCurrent files: {count}")
