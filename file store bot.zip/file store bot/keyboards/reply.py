"""Reply keyboards for the admin panel."""

from __future__ import annotations

from aiogram.types import KeyboardButton, ReplyKeyboardMarkup

_BUTTON_UPLOAD = "Upload New Post"
_BUTTON_CANCEL = "Cancel Current Upload"
_BUTTON_STATS = "Statistics"
_BUTTON_FINISH = "Finish Upload"


def admin_panel_keyboard(with_finish: bool = False) -> ReplyKeyboardMarkup:
    """Admin main menu; optionally adds the Finish Upload button mid-upload."""
    rows: list[list[KeyboardButton]] = [
        [KeyboardButton(text=_BUTTON_UPLOAD)],
        [KeyboardButton(text=_BUTTON_CANCEL), KeyboardButton(text=_BUTTON_STATS)],
    ]
    if with_finish:
        rows.append([KeyboardButton(text=_BUTTON_FINISH)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)
