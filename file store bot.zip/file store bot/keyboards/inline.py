"""Inline keyboards for users and the channel."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def download_keyboard(bot_username: str, post_id: int) -> InlineKeyboardMarkup:
    """Beautiful Download button attached to the published channel post.

    The button is a deep link that opens a chat with the bot and automatically
    triggers the download of the matching post.
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="\U0001F4E5 Download Files",
                    url=f"https://t.me/{bot_username}?start=download_{post_id}",
                )
            ]
        ]
    )
